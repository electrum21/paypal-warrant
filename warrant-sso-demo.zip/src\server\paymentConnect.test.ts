import { createHash, randomUUID } from "node:crypto";
import type { AddressInfo } from "node:net";
import { afterEach, describe, expect, it, vi } from "vitest";
import type { Config } from "../config.js";
import { openDb } from "../db/index.js";
import { newUser } from "../agent/buyer.js";
import { registerUserKey } from "../repo.js";
import { createApp } from "./app.js";

const cfg = {
  PAYPAL_CLIENT_ID: "id", PAYPAL_CLIENT_SECRET: "secret", DATABASE_PATH: ":memory:", PORT: 0, APP_URL: "https://app.test",
  ADMIN_TOKEN: "admin", ANTHROPIC_MODEL: "m", GEMINI_MODEL: "g", ENFORCE_MANDATE: false, MERCHANT_ID: "warrant-demo-merchant",
  ELASTIC_INDEX: "i", AUTH_SESSION_HOURS: 24,
} as unknown as Config;

const realFetch = globalThis.fetch;
const hash = (value: string) => createHash("sha256").update(value).digest("hex");
type SetupToken = { id: string; status: string; links: { rel: string; href: string; method?: string }[] };

/** What the fake /v3/vault/setup-tokens endpoint replies with. A lone `self` link is what an unprovisioned app returns. */
let setupTokenReply: SetupToken;
let setupRequests: { body: any }[] = [];

/** PayPal is faked; calls to the local test server go through untouched. */
function stubPayPal() {
  vi.stubGlobal("fetch", (url: string, init?: any) => {
    if (!String(url).startsWith("https://api-m.sandbox.paypal.com")) return realFetch(url, init);
    const json = (o: unknown) => Promise.resolve(new Response(JSON.stringify(o), { status: 200 }));
    if (String(url).includes("/oauth2/token")) return json({ access_token: "t", expires_in: 3600 });
    setupRequests.push({ body: init?.body ? JSON.parse(init.body) : undefined });
    return json(setupTokenReply);
  });
}

/** Signs a user in the way /auth/paypal/callback would: a random token whose sha256 is stored server-side. */
function signIn(db: ReturnType<typeof openDb>, userId: string) {
  const token = randomUUID() + randomUUID();
  db.prepare("INSERT INTO auth_sessions (session_id_hash, user_id, email, display_name, expires_at) VALUES (?, ?, ?, ?, ?)")
    .run(hash(token), userId, "buyer@example.com", "Buyer", new Date(Date.now() + 3600_000).toISOString());
  return token;
}

function start(userId: string) {
  const db = openDb();
  const user = newUser(userId);
  registerUserKey(db, user.userId, user.publicKeyPem);
  const token = signIn(db, user.userId);
  const server = createApp(cfg, db, {}).listen(0);
  return { db, token, server, base: `http://127.0.0.1:${(server.address() as AddressInfo).port}` };
}

const post = (base: string, token: string) => realFetch(`${base}/api/me/payment/start`, {
  method: "POST", headers: { cookie: `warrant_session=${token}`, "content-type": "application/json" }, body: "{}",
});

afterEach(() => {
  vi.unstubAllGlobals();
  setupRequests = [];
});



describe("POST /api/me/payment/start", () => {
  it("answers 502 with actionable diagnostics when PayPal returns a setup token with no payer-action link", async () => {
    // Reproduces the live sandbox failure: status CREATED, self link only, no payer session.
    setupTokenReply = { id: "SETUP-1", status: "CREATED", links: [{ rel: "self", href: "https://api-m.sandbox.paypal.com/v3/vault/setup-tokens/SETUP-1", method: "GET" }] };
    stubPayPal();
    const { db, token, server, base } = start("u1");
    try {
      const r = await post(base, token);
      const body = await r.json() as any;
      expect(r.status).toBe(502);
      expect(body).toMatchObject({ error: "PayPal did not return a payment approval link.", providerStatus: "CREATED", setupTokenId: "SETUP-1", expectedStatus: "PAYER_ACTION_REQUIRED" });
      expect(body.providerLinks.map((l: any) => l.rel)).toEqual(["self"]);
      // The response must tell the operator exactly which dashboard toggles to flip.
      expect(body.fix.join(" ")).toContain("Vault");
      expect(body.fix.join(" ")).toContain("Save PayPal and Venmo payment methods");
      // The request PayPal received was a wallet vault setup, so the missing link is on PayPal's side.
      expect(setupRequests[0].body.payment_source.paypal.vault).toEqual({ store_in_vault: "ON_SUCCESS" });
      expect(setupRequests[0].body.payment_source.paypal.experience_context.return_url).toContain("/paypal/payment-return?state=");
      // A session with no approvable token must not be persisted for the return leg to trip over.
      expect(db.prepare("SELECT COUNT(*) c FROM payment_setup_sessions").get()).toEqual({ c: 0 });
    } finally {
      await new Promise<void>(resolve => server.close(() => resolve()));
    }
  });

  it("returns the approve URL and stores the setup session when PayPal opens a payer session", async () => {
    setupTokenReply = { id: "SETUP-2", status: "PAYER_ACTION_REQUIRED", links: [
      { rel: "self", href: "https://api-m.sandbox.paypal.com/v3/vault/setup-tokens/SETUP-2", method: "GET" },
      { rel: "payer-action", href: "https://www.sandbox.paypal.com/checkoutnow?token=SETUP-2", method: "GET" },
    ] };
    stubPayPal();
    const { db, token, server, base } = start("u2");
    try {
      const r = await post(base, token);
      expect(r.status).toBe(200);
      expect(await r.json()).toEqual({ approveUrl: "https://www.sandbox.paypal.com/checkoutnow?token=SETUP-2" });
      const row = db.prepare("SELECT user_id, setup_token_id FROM payment_setup_sessions").get() as { user_id: string; setup_token_id: string };
      expect(row).toEqual({ user_id: "u2", setup_token_id: "SETUP-2" });
    } finally {
      await new Promise<void>(resolve => server.close(() => resolve()));
    }
  });
});

